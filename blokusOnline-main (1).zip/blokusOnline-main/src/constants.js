
// Visual scaling and adjusting for grid and pieces
export const BOARD_SIZE = 20;
export const PIECE_SCALE = 1.15;
export const SHRINK_PERCENT = 0.3 * PIECE_SCALE;
